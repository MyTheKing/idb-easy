<template>
  <main class="main">
    <button @click="add">添加</button>
    <button @click="update">更新表数据</button>
    <button @click="updateData">修改某一项</button>
    <button @click="updateVersion">更新版本</button>
    <button @click="queryIndex">查询某主键项数据</button>
    <button @click="readAllTables">读取所有表数据</button>
    <button @click="readAll">读取某一个表</button>
    <button @click="indexQuery">索引查询</button>
    <button @click="remove">删除指定的</button>
    <button @click="deleteDB">删除数据库的</button>
  </main>
</template>
<script setup>
import TheWelcome from "../components/TheWelcome.vue";
import idbEasy from "idb-easy";
import getData from "@/common/data";
import { ref } from "vue";
import { homeData } from "@/api/index";

const list = ref([]);

let createIndex = [
  {
    indexName: "queryShopId",
    keyPath: "shopId",
    options: {
      unique: true,
    },
  },
  {
    indexName: "queryShopName",
    keyPath: "shopName",
    options: {
      unique: false,
    },
  },
];

let db;

homeData().then((res) => {
  console.log(res.data);
  list.value = res.data;
  // 创建实例
  db = new idbEasy("test", "data1", "shopId", true, createIndex, 1);
  // 创建数据库
  db.open()
    .then((database) => {
      console.log("数据库已成功打开:", database);
    })
    .catch((error) => {
      console.error("打开数据库失败:", error);
    });
});

// 添加数据
const add = () => {
  list.value.forEach((value) => {
    db.addOrUpdate("add", JSON.parse(JSON.stringify(value)), "data1")
      .then((res) => {
        console.log("添加成功");
      })
      .catch((error) => {
        console.log("添加失败", error);
      });
  });

  db.addOrUpdate("add", new Date().getTime(), "data1")
    .then((res) => {
      console.log("添加成功");
    })
    .catch((error) => {
      console.log("添加失败", error);
    });
};

let obj = {
  shopId: 108,
  shopMSg: "hhhh",
};
// 更新表数据
const update = () => {
  db.addOrUpdate("put", obj, "data1")
    .then((res) => {
      console.log("更新成功");
    })
    .catch((error) => {
      console.log(error, "更新");
    });
};

// 更新某主键项数据
const updateData = () => {
  db.updateData(158, { shopMsg: "66666", shopName: "6666.66" })
    .then((res) => {
      console.log("更新成功");
    })
    .catch((error) => {
      console.log(error, "更新失败");
    });
};

// 版本更新
const updateVersion = () => {
  let createIndex = [
    {
      indexName: "phone",
      keyPath: "shopTel",
      options: {
        unique: false,
      },
    },
  ];

  db.updateVersion(6, "data2", "shopId", true, createIndex)
    .then((database) => {
      console.log("数据库已更新:", database);
    })
    .catch((error) => {
      console.error("更新数据库失败:", error);
    });
};

// 查询某主键项数据
const queryIndex = () => {
  db.queryIndex(101, "data1")
    .then((res) => {
      console.log(res);
    })
    .catch((error) => {
      console.log(error);
    });
};

// 读取全部表数据
const readAllTables = () => {
  db.readAllTables()
    .then((res) => {
      console.log(res);
    })
    .catch((error) => {
      console.log(error, "读取数据失败");
    });
};

// 读取数据
const readAll = () => {
  db.readAll("data1")
    .then((res) => {
      console.log(res);
    })
    .catch((error) => {
      console.log(error, "读取数据失败");
    });
};

// 索引查询
const indexQuery = () => {
  db.indexQuery("phone", "13312345678", "data2")
    .then((res) => {
      console.log(res);
    })
    .catch((error) => {
      console.log(error, "查询失败");
    });
};

// 删除表中指定主键项数据
const remove = () => {
  db.remove(102, "data2")
    .then((res) => {
      console.log("删除成功");
    })
    .catch((error) => {
      console.log(error, "删除失败");
    });
};

// 删除数据
const deleteDB = () => {
  db.deleteDB("test")
    .then((res) => {
      console.log("删除成功" + res);
    })
    .catch((err) => {
      console.log("删除失败" + err);
    });
  location.reload();
};
</script>

<style>
.main {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

button {
  padding: 5px 10px;
  border-radius: 5px;
  border: none;
  background-color: rgb(129, 175, 235);
}

button:hover {
  background-color: rgb(129, 152, 235);
}
</style>
