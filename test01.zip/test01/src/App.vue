
<template>
  <RouterView />
</template>


<style scoped>
 * {
  padding: none;
  margin: none;
 }
 body,html {
  width: 100vh;
  height: 100vh;
 }
</style>
