export default [
  {
    "shopId": 101,
    "shopMsg": "精美商品",
    "shopName": "张伟",
    "shopTel": "15012345678",
    "shopAddress": "北京市朝阳区",
    "shopStar": "★★★",
    "salesVolume": 300,
    "shopLogo": "http://example.com/logo1.png",
    "food": [
      {
        "foodName": "李华",
        "foodPic": "http://example.com/foodpic1.png",
        "foodPrice": 50,
        "aname": [
          {
            "aname": "王五",
            "aprice": 45
          }
        ]
      },
      {
        "foodName": "赵六",
        "foodPic": "http://example.com/foodpic2.png",
        "foodPrice": 35,
        "aname": [
          {
            "aname": "陈七",
            "aprice": 50
          }
        ]
      }
    ]
  },
  {
    "shopId": 102,
    "shopMsg": "优质选择",
    "shopName": "李雷",
    "shopTel": "13812345678",
    "shopAddress": "上海市浦东新区",
    "shopStar": "★★★★",
    "salesVolume": 500,
    "shopLogo": "http://example.com/logo2.png",
    "food": [
      {
        "foodName": "韩梅梅",
        "foodPic": "http://example.com/foodpic3.png",
        "foodPrice": 70,
        "aname": [
          {
            "aname": "周八",
            "aprice": 35
          }
        ]
      },
      {
        "foodName": "林涛",
        "foodPic": "http://example.com/foodpic4.png",
        "foodPrice": 45,
        "aname": [
          {
            "aname": "吴九",
            "aprice": 30
          }
        ]
      }
    ]
  },
  {
    "shopId": 103,
    "shopMsg": "新鲜上市",
    "shopName": "王强",
    "shopTel": "17712345678",
    "shopAddress": "广州市天河区",
    "shopStar": "★★",
    "salesVolume": 700,
    "shopLogo": "http://example.com/logo3.png",
    "food": [
      {
        "foodName": "赵敏",
        "foodPic": "http://example.com/foodpic5.png",
        "foodPrice": 60,
        "aname": [
          {
            "aname": "钱十",
            "aprice": 40
          }
        ]
      },
      {
        "foodName": "孙武",
        "foodPic": "http://example.com/foodpic6.png",
        "foodPrice": 80,
        "aname": [
          {
            "aname": "江十一",
            "aprice": 45
          }
        ]
      }
    ]
  },
  {
    "shopId": 104,
    "shopMsg": "特色产品",
    "shopName": "周杰",
    "shopTel": "18812345678",
    "shopAddress": "深圳市南山区",
    "shopStar": "★★★★★",
    "salesVolume": 200,
    "shopLogo": "http://example.com/logo4.png",
    "food": [
      {
        "foodName": "吴芳",
        "foodPic": "http://example.com/foodpic7.png",
        "foodPrice": 30,
        "aname": [
          {
            "aname": "郑十二",
            "aprice": 35
          }
        ]
      },
      {
        "foodName": "郑丽",
        "foodPic": "http://example.com/foodpic8.png",
        "foodPrice": 55,
        "aname": [
          {
            "aname": "王十三",
            "aprice": 50
          }
        ]
      }
    ]
  },
  {
    "shopId": 105,
    "shopMsg": "特惠商品",
    "shopName": "李明",
    "shopTel": "15512345678",
    "shopAddress": "成都市武侯区",
    "shopStar": "★★★★",
    "salesVolume": 800,
    "shopLogo": "http://example.com/logo5.png",
    "food": [
      {
        "foodName": "刘洋",
        "foodPic": "http://example.com/foodpic9.png",
        "foodPrice": 25,
        "aname": [
          {
            "aname": "陈十四",
            "aprice": 30
          }
        ]
      },
      {
        "foodName": "陈浩",
        "foodPic": "http://example.com/foodpic10.png",
        "foodPrice": 40,
        "aname": [
          {
            "aname": "杨十五",
            "aprice": 55
          }
        ]
      }
    ]
  },
  {
    "shopId": 106,
    "shopMsg": "精选好货",
    "shopName": "王丽",
    "shopTel": "13312345678",
    "shopAddress": "杭州市西湖区",
    "shopStar": "★",
    "salesVolume": 900,
    "shopLogo": "http://example.com/logo6.png",
    "food": [
      {
        "foodName": "张静",
        "foodPic": "http://example.com/foodpic11.png",
        "foodPrice": 90,
        "aname": [
          {
            "aname": "赵十六",
            "aprice": 60
          }
        ]
      },
      {
        "foodName": "刘婷",
        "foodPic": "http://example.com/foodpic12.png",
        "foodPrice": 75,
        "aname": [
          {
            "aname": "郭十七",
            "aprice": 45
          }
        ]
      }
    ]
  }
]