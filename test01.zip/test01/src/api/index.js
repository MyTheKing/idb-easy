import request from "@/utils/request";



export const homeData=()=> {
    return request.post('goods/goodAll')
}
